1 member group - Tushar Chaudhary
redid - 823343060
Code- 01011011
Files included - Readme file, LAB3.clf, and maincircuit.cct

First i started with the state diagram (Backbone) using my CODE, which later on helped me to make my state table.
I could build Kmaps from my table which was essential to get my equations. From those equations i could easily draw out my circuits.
My equations were - 
D1 = AC'x+ A'BCX + AB'CX'
D2 = AB'X' + ACX' + A'B'CX + A'BC'X' + ABC'X
D3 = A'x' + B'X' + AC'

I used grey codes to assign states.  